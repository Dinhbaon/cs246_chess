#ifndef COLOR_H
#define COLOR_H

enum Color {WHITE, BLACK}; 

#endif