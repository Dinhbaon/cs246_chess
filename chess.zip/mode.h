#ifndef MODE_H
#define MODE_H

enum Mode {SETUP, GAME, START}; 

#endif