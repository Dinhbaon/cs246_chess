#ifndef PIECETYPE_H
#define PIECETYPE_H

enum PieceType{PAWN, QUEEN, KING, ROOK, BISHOP, KNIGHT}; 

#endif